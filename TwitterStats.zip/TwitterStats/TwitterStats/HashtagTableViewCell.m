//
//  HashtagTableViewCell.m
//  TwitterStats
//
//  Created by Cameron Weston on 7/5/17.
//  Copyright © 2017 cameron weston personal. All rights reserved.
//

#import "HashtagTableViewCell.h"

@implementation HashtagTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
