//
//  PopUpViewController.h
//  TwitterStats
//
//  Created by Cameron Weston on 5/4/17.
//  Copyright © 2017 cameron weston personal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopUpViewController : UIViewController

- (void)showInView:(UIViewController *)aViewController animated:(BOOL)animated;

@end
