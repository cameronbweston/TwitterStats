//
//  CollectionViewCell.m
//  TwitterStats
//
//  Created by Cameron Weston on 4/28/17.
//  Copyright © 2017 cameron weston personal. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
