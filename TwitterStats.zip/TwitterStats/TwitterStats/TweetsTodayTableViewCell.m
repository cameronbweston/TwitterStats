//
//  TweetsTodayTableViewCell.m
//  TwitterStats
//
//  Created by Cameron Weston on 6/23/17.
//  Copyright © 2017 cameron weston personal. All rights reserved.
//

#import "TweetsTodayTableViewCell.h"

@implementation TweetsTodayTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
